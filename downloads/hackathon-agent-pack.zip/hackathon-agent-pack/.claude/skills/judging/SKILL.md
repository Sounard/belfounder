---
name: judging
description: Compute judge counts, design the rubric and scoring flow, generate judge briefings — or design a no-judging format when the goal calls for it.
---

# /judging — fair, fast, or none at all

Works on `event/05-JUDGING.md`. Pull goal and headcount from 00-BRIEF.

## First question: should this event judge at all?

If the goal is conversion or community: recommend peer voting (each attendee tags
projects; awards from frequency), completion-based recognition (everyone who ships
gets the reward), or many small named awards. Multiply winning identities; delete the
most failure-prone logistics of the event.

If judging: proceed.

## The math (compute, show your work)

- Projects ≈ checked-in attendees ÷ 4.
- Judges = ⌈(projects × 3 judges × 4 min) / judging window⌉.
  (175 projects / 2h → 18 judges.) Online: ~30 projects ≈ 5h per judge; 1–2 week window.
- Science-fair format, judges circulate, staggered assignments so no two judges see the
  same cohort. Never judging rooms; **never eliminate teams before submissions**.

## Rubric

Spine: working demo · technical execution · originality · impact. Offer differentiators
by goal: *shippability* ("could we use this next week?") for corporate; *simplicity*
and *documentation* for adoption events; *storytelling* and *care* for civic/beginner
events. **Publish the rubric at kickoff** — it's a steering instrument, not a secret.

## Scoring

Stack ranking: each judge returns only a top 3 (3/2/1 points). No raw score sheets —
stack ranking normalizes harsh vs. generous judges and runs in a spreadsheet.
Organizers personally validate + rules-check the top 5 before announcing. Brief judges
to reward learning over startup polish.

## Generate

1. Judge count + recruitment plan (who, from where, confirm at T-2mo and T-1wk).
2. The published rubric.
3. Scoring sheet (markdown table or CSV).
4. 15-minute calibration script (walk one imaginary project through the rubric
   together; align on what a 2-minute demo can and can't prove; what to do when a live
   demo breaks for infra reasons — judge the artifact shown, not the luck).
5. Judge day-of briefing: `templates/judge-briefing.md` personalized.
