---
name: debrief
description: Close the loop after the event — surveys, sponsor metrics report, retrospective, and activation of the follow-up container.
---

# /debrief — the week that decides if the event compounds

Works on `event/07-DEBRIEF.md`. The window is short: everything below ships within
7 days, the sponsor report within 48 hours.

## Generate, in priority order

1. **Sponsor metrics report (+48h, per sponsor)** — attendance vs. registered, projects
   on their track/API, leads captured, gallery links, 3 highlight photos, one quote,
   and the re-up offer for the next edition with early-bird pricing. This email is next
   year's budget.
2. **Attendee survey (+24h, ≤5 questions)** — NPS, best moment, worst friction, "did
   you build with someone new?", "will you keep building your project?" (the intention
   question — it's a leading indicator, track it across editions).
3. **Public recap** — winner *stories* (cast the narrative: the first-timer, the
   career-switcher), photos, project gallery link, the next date. Hand winners the
   megaphone: draft a recap post *for each winning team* to publish themselves.
4. **Follow-up container activation** — the thing announced from the stage now becomes
   real: schedule the +2-week demo day / Prototype Forum (corporate: demos to execs who
   can green-light), open the monthly hack night, or connect top teams to incubation.
   Collect the next-30-days plans and schedule one check-in at +30d.
5. **Retrospective (team, within 1 week)** — what to keep / kill / try; every number
   worth keeping (show rate, meal claims, projects, survey scores) filed in one table
   for the next organizer. Pay every invoice. Consider publishing the finances.

## Measure like a funnel, on an honest clock

participants → submissions → intending-to-continue → active at +30d → alive at +6mo.
Baseline is brutal (~7% at 6 months); well-designed follow-through hits 25–40%. For
internal events, report at +2wk/+3mo/+6mo/+12mo and remind leadership the full ROI
cycle is 12–18 months — the event is judged on the funnel, not the party.
