---
name: run-of-show
description: Generate or revise the minute-by-minute event schedule with an owner per block, built on flow psychology and the double close.
---

# /run-of-show — choreograph the day

Works on `event/04-RUN-OF-SHOW.md`. Pull goal/length/size from 00-BRIEF.

## Non-negotiable skeleton (any length)

1. **Threshold** — arrival is a ritual: named check-in, badge, music, the room says
   "something happens here". QR + paper backup.
2. **Opening ≤15 min** — mission cold-open (why this, why now, why these people) →
   the ONE goal with the clock ("working demo, live, no slides, at HH:MM") → rubric
   published → rules in 5 → teams confirmed → go. **Never open with wifi passwords.**
3. **Protected build blocks** — the longest uninterrupted stretches the length allows.
   Workshops/mentor hours at fixed windows only. Mentors circulate on a schedule
   (first-timers don't ask). Newcomer shepherd on duty from minute one.
4. **Mid-point checkpoint** — every team states what they're cutting (teams finish
   ~25% of scope; force the cut early, not at hour 40).
5. **Energy punctuation** — meals at shared tables (social glue, not grab-and-go), one
   surprise micro-event, quiet room for >12h, sleep framed as strategy for >24h.
   T-1h warning before hands-off.
6. **Next-30-days moment** — before demos, every team writes the 2-line plan.
7. **Demos** — everyone, live, 2–3 min, hard-cut timer, no slides. <200 people → full
   room; >200 → science fair (3 judges/project, staggered) + top-N on stage; broadcast
   judging progress.
8. **Double close** — inward: winner *stories* and a beat of reflection; outward: next
   date + community channel + where projects live. **Never end on prize logistics.**

## Rules

- Every block has an owner (a name, not a team).
- Plan content for 80–85% of each slot — slack is a design requirement.
- Emit as a table: time / block / owner / notes. For multi-day, one table per day.
- If the user's requests fragment the build blocks, push back once with the reason
  (fragmented pressure kills creativity), then comply with a `> ⚠ Deviation:` note.
