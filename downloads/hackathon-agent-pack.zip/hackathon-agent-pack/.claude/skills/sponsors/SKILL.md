---
name: sponsors
description: Run the sponsorship pipeline — prospectus, target list, outreach emails, follow-ups, and the post-event sponsor report.
---

# /sponsors — sponsorship as a sales pipeline

Works on `event/03-SPONSORS.md` (create it if missing; pull context from 00-BRIEF and
02-BUDGET).

## Doctrine

Sponsors buy one of three things — package for ONE lane per tier, never a logo-size
ladder:
- **Adoption** (DevRel budgets): "Best Use of X" track (X kept general), workshop slot,
  dedicated channel, pre-event setup webinar, their engineers walking the floor.
- **Recruiting** (HR budgets, hottest in autumn): resume book, interview room, booth,
  short opening slot.
- **Brand** (marketing budgets): lanyards, shirts, badges, content, association.

Rules you enforce: 2–3 page prospectus; 3 tiers; **top tier ≤25% of total budget**;
prize parity across sponsors (one $50k prize kills everyone else's ROI); ≥4 prizes
total; credits/access welcome but never let credits-only sponsors displace the cash
that feeds people; Q1/Q4 are the loosest quarters.

## What you do on invocation

1. **Prospectus** — draft/refresh from `templates/prospectus-outline.md`, priced from
   the budget file.
2. **Target list** — 10+ names matched to theme and lane (local scene first), each with
   the right title to email (DevRel / HR / Marketing / CEO — never a random engineer).
3. **Outreach** — personalize `templates/sponsor-first-email.md` per target.
   First email: plain text, ZERO links/attachments/images. Prospectus goes in the
   follow-up. Sequence: email → call (script: "what did you spend on similar events and
   what did you get?") → same-day custom proposal → follow-ups at +10d and +20d →
   **invoice the moment they say yes**.
4. **Pipeline table** — maintain: target / contact / lane / tier / status / last touch /
   next follow-up date. When invoked, list every follow-up that is due or overdue.
5. **Post-event** — generate the sponsor metrics report (due +48h): attendance,
   projects on their API/track, leads, gallery links, photos, and the re-up offer for
   next edition. This email is next year's budget — treat it as a deliverable, not a
   courtesy.
