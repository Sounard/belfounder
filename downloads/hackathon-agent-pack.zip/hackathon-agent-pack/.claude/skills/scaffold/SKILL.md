---
name: scaffold
description: Interview the organiser (10 questions) and generate the complete event scaffold — brief, timeline, budget, sponsor plan, run of show, judging, comms, debrief — as files in event/.
---

# /scaffold — one prompt to a fully planned event

## Step 1 — The interview (keep it to ~10 questions, taste only)

Ask in one or two batches, conversationally. Never ask anything you can default or
compute. The questions:

1. **Goal** — what must be true the Monday after? (first-timers converted / prototypes
   shipped / community energized / talent found / tool launched) ← the only blocking one
2. **Who's it for** — students, working builders, employees, kids, mixed?
3. **Date & city/venue status** — date picked? venue leads?
4. **Size ambition** — rough headcount.
5. **Length instinct** — 3h / 12h / 24–48h / multi-week? (Recommend from goal: elite
   energy → 3–12h; conversion → 1 day sleep-compatible; prototypes → 48h no all-nighter;
   corporate → 24h + Prototype Forum at +2 weeks.)
6. **Money** — budget in hand, sponsors to raise, or internal funding?
7. **Entry philosophy** — open door or curated? (Recommend from goal.)
8. **Theme** — a cause, a technology, a launch, or open? (Remind: theme is a demographic
   instrument — it decides who shows up.)
9. **The room** — what should someone feel at the door? (prestige / playground /
   mission HQ / campfire)
10. **The afterlife** — is there a container after the event (community, incubation,
    next edition), or do we create one?

Accept partial answers; default the rest and say so.

## Step 2 — Generate `event/` (all eight files, in this order)

Convert every T-minus offset in `../checklist/MASTER-TIMELINE.md` (Track A or B, per
length) to real calendar dates. Flag anything already late as `⚠ LATE — recovery:`.

- `00-BRIEF.md` — goal in one sentence; the format decisions that follow from it
  (entry, teaming, judging, prizes, length) each with a one-line "because".
- `01-TIMELINE.md` — dated countdown with an owner column (default owner: the user;
  mark gaps `OWNER NEEDED`).
- `02-BUDGET.md` — line items from headcount × benchmark numbers, contingency $1–3k,
  a funding-gap line if sponsors are needed.
- `03-SPONSORS.md` — three tiers anchored to lanes (adoption/recruiting/brand), price
  points sized so top tier ≤25% of budget, a 10-target hit list matched to the theme,
  pipeline table (target / contact / status / next follow-up date). Use
  `templates/sponsor-first-email.md` and `templates/prospectus-outline.md`.
- `04-RUN-OF-SHOW.md` — minute-by-minute: threshold, ≤15-min opening (mission →
  one goal → rubric → rules), protected build blocks, fixed mentor windows, mid-point
  checkpoint, next-30-days-plan moment, demos (everyone, 2–3 min, hard cut), double
  close. Owner per block.
- `05-JUDGING.md` — computed judge count, rubric (published-at-kickoff version),
  stack-rank scoring sheet, 15-min calibration script, or a no-judging design if the
  goal calls for it (peer voting / completion awards).
- `06-COMMS.md` — the full sequence, drafted and dated: confirmation, logistics, the
  ONE paperwork deadline, team-formation call, final reminder + countdown, day-of
  announcements, thank-you, recap. Redundant-channel plan.
- `07-DEBRIEF.md` — attendee + sponsor survey questions, sponsor metrics report
  skeleton (due +48h), retro template, follow-up container activation checklist.

## Step 3 — Close the loop

End with: the three next physical actions (usually: venue pitch #1, sponsor email #1,
date lock), the first killer deadline on their calendar, and the offer to run
`/sponsors` or `/comms` next. Ten minutes, done.
