---
name: comms
description: Draft the complete attendee communication sequence — from acceptance to recap — dated, with redundant channels and one consolidated deadline.
---

# /comms — every message, drafted, dated

Works on `event/06-COMMS.md`. Pull dates from 01-TIMELINE, voice from 00-BRIEF.

## Doctrine

- The event starts at the invitation: every message primes builder identity and the
  ONE goal, not logistics-first.
- **One consolidated paperwork deadline** — waivers, forms, team registration, dietary
  needs all due the same date. Scattered micro-deadlines cause decision paralysis.
- Redundant channels: email + community chat + SMS for the critical two (final
  reminder, day-of).
- Registration funnel milestones for a free event: 200% of capacity by T-1 week
  (no-show ~50%). If tracking behind, escalate marketing in the sequence.

## The sequence (adapt count to event length; draft ALL of them now)

| # | When | Message | Job |
|---|---|---|---|
| 1 | On acceptance | Welcome / you're in | Identity + the one goal + date holds |
| 2 | T-3wk | Logistics #1 | Venue, times, what to bring, team-formation channel opens |
| 3 | T-2wk | **The Deadline email** | Everything owed, ONE date, checklist format |
| 4 | T-10d | Team formation push | Teams of 3–4 by hour zero; matching thread/form |
| 5 | T-1wk | Deadline reminder | Same list, escalating urgency, SMS backup |
| 6 | T-3d | Hype + judges reveal | Countdown, judge lineup, prizes (access-framed) |
| 7 | T-1d | Final logistics | Doors, map, schedule, the one goal, sleep well |
| 8 | Day-of | Announcements cadence | Opening, checkpoint, T-1h warning, demo order |
| 9 | +1d | Thank you + survey | 5 questions max, link to gallery |
| 10 | +3–7d | Recap | Winner stories, photos, **next date**, community channel |

Also generate: waitlist message, rejection-with-dignity message (roll them into the
next event's audience), and the parent/employer permission variant when the audience
needs it.

Emit each message with subject line, channel, send date, and body ready to paste.
