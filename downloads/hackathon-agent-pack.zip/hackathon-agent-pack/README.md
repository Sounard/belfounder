# The Hackathon Organiser Agent Pack

**Bachelor student → world-class organiser in one prompt and 10 minutes.**

This is a Claude Code skill pack. It turns Claude Code into a hackathon co-organiser
that carries the distilled knowledge of 35+ playbooks (MLH, Facebook, Atlassian, NASA,
Cerebral Valley, the CMU research corpus…) and generates your entire event as files —
timeline, budget, sponsor prospectus, run of show, comms calendar, judging plan.

## Install (2 minutes)

```bash
# 1. Get the pack (clone the playbook repo, or copy this folder)
cd hackathon-playbook/agent-pack

# 2. Start Claude Code here
claude
```

That's it. `CLAUDE.md` and the skills in `.claude/skills/` load automatically.

## The one prompt (10 minutes)

```
/scaffold
```

The agent interviews you — ten questions, taste-level decisions only — then writes a
complete `event/` directory:

```
event/
  00-BRIEF.md            your goal, format, and the decisions that follow from it
  01-TIMELINE.md         your dates on the master countdown, owners assigned
  02-BUDGET.md           line items with benchmark numbers, contingency included
  03-SPONSORS.md         prospectus draft + target list + pipeline tracker
  04-RUN-OF-SHOW.md      minute-by-minute, owner per block
  05-JUDGING.md          judge count (computed), rubric, scoring sheet, briefing
  06-COMMS.md            every email/announcement, drafted, dated
  07-DEBRIEF.md          surveys, sponsor report skeleton, retro template
```

Then iterate with the specialist skills whenever you need them:

| Skill | What it does |
|---|---|
| `/scaffold` | The 10-question interview → full event scaffold |
| `/sponsors` | Prospectus, outreach emails, pipeline CRM, follow-up nudges |
| `/run-of-show` | (Re)generate the minute-by-minute schedule |
| `/judging` | Judge math, rubric, calibration script, scoring sheet |
| `/comms` | The full attendee email sequence, ready to send |
| `/debrief` | Post-event: surveys, sponsor metrics report, retrospective |

## What makes it opinionated

The agent enforces the field-tested defaults (200% overbooking, one paperwork deadline,
judge formula, prize parity, sleep-compatible schedules, the written next-30-days plan,
the double close) and tells you when you're about to make a documented mistake. You can
override anything — it will comply, and note the risk in the generated file.

Knowledge base: `../playbook/FIELD-MANUAL.md`, `../checklist/MASTER-TIMELINE.md`,
`../research/INSIGHT-BANK.md`. Copy-paste artifacts: `templates/`.
