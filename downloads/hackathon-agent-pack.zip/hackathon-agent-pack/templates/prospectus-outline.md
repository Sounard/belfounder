# Sponsor prospectus — 2–3 pages, no more

Rules: three tiers, each anchored to ONE buyer lane. Top tier ≤25% of your total
budget. Prize parity across sponsors. Always offer custom packages. PDF, designed
lightly, numbers up front.

## Page 1 — The event

- Name, date, city, venue (photo).
- One sentence: what happens and who's in the room.
- The numbers bar: expected attendees · % students vs. professionals · projects
  expected (attendees ÷ 4) · past-edition stats or community size.
- Who else is in (anchor brands legitimize you — list confirmed partners early).

## Page 2 — The tiers

| | 🥉 {NAME} — Brand | 🥈 {NAME} — Recruiting | 🥇 {NAME} — Adoption |
|---|---|---|---|
| Price | € | €€ | €€€ (≤25% of budget) |
| Logo + social | ✓ | ✓ | ✓ |
| Swag/surfaces (lanyards, shirts) | ✓ | ✓ | ✓ |
| Booth + floor presence | | ✓ | ✓ |
| Resume book + interview room | | ✓ | ✓ |
| Opening-ceremony slot (short) | | ✓ | ✓ |
| "Best Use of X" challenge track | | | ✓ |
| Workshop slot + dedicated channel | | | ✓ |
| Pre-event setup webinar | | | ✓ |
| Judge seat | | | ✓ |

Credits/in-kind: welcomed as add-ons; API credits for all participants is a first-class
adoption deliverable. (Keep some cash tiers — someone has to feed the builders.)

## Page 3 — Why it works + logistics

- What sponsors got last time (integrations built, hires made, content produced) — or
  the design that guarantees it (demo-or-die, curated room, staffed-floor requirement).
- Your commitment to them: post-event metrics report within 48h.
- Their commitment to you: a staffed table and humans walking the floor (presence is
  what makes sponsorship work — say it in the deck).
- Contact + invoice details.
