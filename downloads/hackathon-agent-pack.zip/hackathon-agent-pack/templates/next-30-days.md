# The next-30-days card

Print one per team. Hand out 30 minutes before demos; collect a photo of each at
check-in to the demo stage. This two-line ritual is the single cheapest predictor of
whether a project survives the weekend (written intention formed at peak motivation).

---

## {EVENT NAME} — What happens next

**Team:** ______________________ **Project:** ______________________

**In the next 30 days, we will:**

1. ________________________________________________________________

2. ________________________________________________________________

**The first step happens on (date):** ______________

**Who's on it:** ______________________

**Where the project will live (repo / page / channel):** ______________________

---

*We'll check in on {DATE +30d}. The {FOLLOW-UP CONTAINER — demo day / hack night /
community channel} is on {DATE} — bring what you've got, whatever state it's in.*
