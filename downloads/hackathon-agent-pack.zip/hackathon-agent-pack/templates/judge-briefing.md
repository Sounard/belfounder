# Judge briefing — one page, sent T-3 days + spoken at calibration

Thank you for judging {EVENT}. Here's everything, in two minutes.

**When/where:** arrive {TIME} at {PLACE}; judging runs {WINDOW}; you're free by {END}.

**Format:** science fair. You'll visit ~{N} assigned projects, ~4 minutes each
(2 min demo, 1 min questions, 1 min walking). Assignments are staggered — judge only
your list.

**The rubric (participants have had it since kickoff):**
{RUBRIC — e.g. working demo · technical execution · originality · impact}

**How you score:** you don't fill scorecards. At the end, give us your **top 3**, in
order. That's it. (We aggregate 3/2/1 across judges and verify the leaders ourselves.)

**Calibration notes:**
- Judge the artifact, not the slideware — a wobbly live demo of a real thing beats a
  polished deck of a fake one.
- Reward learning and ambition over startup polish. Most of these people aren't
  fundraising; some are building for the first time. The first-timer who shipped
  something real is exactly who this event is for.
- If a live demo breaks for infrastructure reasons, ask them to show it another way —
  judge what was built, not the luck.
- 2 minutes can't prove scalability. Don't ask it to.
- You're a highlight of their weekend. Be generous with questions; your attention is
  part of the prize.

**Day-of contact:** {NAME} — {PHONE}.
