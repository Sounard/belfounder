# Sponsor first-touch email

Rules: plain text. Zero links, zero attachments, zero images (corporate spam filters
kill them — the prospectus goes in the follow-up). To a DevRel / Recruiting / Marketing
title, or the CEO. Never a random engineer.

---

Subject: {EVENT NAME} — {N} builders in {CITY}, {MONTH}

Hi {FIRST NAME},

I'm {NAME}, organising {EVENT NAME} — {ONE LINE: what it is, e.g. "a 12-hour AI build
day bringing 150 selected builders together in Brussels on 14 March"}.

Why I'm writing to you specifically: {ONE LINE connecting their company to the event —
their API fits the theme / they're hiring the profile in the room / they sponsored a
similar event}.

Last edition / our traction so far: {ONE PROOF POINT — registrations, venue, partners,
or for a first edition: the team and the community behind it}.

We have a small number of partner slots. Depending on what matters to you — developers
building on your product, meeting the talent in the room, or brand presence — there's
a package shaped for it, from {LOW} to {HIGH}.

Worth a 20-minute call this week or next?

{NAME}
{ROLE, EVENT} · {PHONE}

---

## Follow-up cadence

- +10 days: short bump + attach the prospectus now. "Circling back — attaching the
  partner deck. The {TIER} slots are moving; happy to hold one for a call."
- +20 days: final bump, one line, offer the custom option.
- On the call, ask directly: "For events like this in the past — what did you spend,
  and what did you get out of it?" Send the customized proposal same day.
- **The moment they say yes: send the invoice.**
