# Opening ceremony script — 15 minutes, hard cap

Never open with logistics. The opening installs the mission and the one goal; the
rules take five minutes at the end.

## 0:00 — Cold open (no "welcome, housekeeping first")

Lights, music cut, one person, one line:

> "{PUNCH LINE — e.g. 'Twelve hours from now, every one of you will have shipped
> something that didn't exist this morning.'}"

## 0:01–0:06 — The mission (why this, why now, why you)

- Why this event exists — the cause, the launch, the city, the moment.
- Why *these* people — "you applied, you were selected, this room is the product."
- The identity line: "Some of you have never built anything. By tonight that sentence
  will be false. That's the whole point."

## 0:06–0:08 — The ONE goal

> "One deliverable: a working demo. Live. No slides. On this stage at {TIME}.
> The clock is on the wall."

## 0:08–0:10 — The rubric (publish it now)

Read the 3–4 criteria out loud. "This is exactly how you win. Build for it."

## 0:10–0:14 — Rules & rhythm, fast

- Teams: 3–4, confirmed by {TIME}. Solo? The matching board is at {PLACE}.
- Help: @mentor in {CHANNEL} + mentors in {COLOR} shirts do rounds every hour.
- Checkpoint at {TIME}: every team states what they're cutting. (You'll finish a
  quarter of what you plan. Everyone does. Cut early.)
- Meals at {TIMES}, shared tables — talk to strangers. Quiet room at {PLACE}.
- Code of conduct: one line, and mean it: "Everyone builds here. Anyone who makes that
  harder gets walked out."
- First-timers: raise your hands. *Applause.* "You're why this exists. {SHEPHERD NAME}
  is yours all day."

## 0:14–0:15 — Go

> "Sponsors fed you, judges cleared their day for you, and the demo stage is already
> set up — it's waiting for you. Build. GO."

Countdown starts on screen. Music up.
