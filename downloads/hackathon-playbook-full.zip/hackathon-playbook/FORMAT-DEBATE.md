# The Format Debate — 10 candidates, 3 shipped

Goal: lowest friction of adoption × highest value, for two readers at once — a bachelor
student who needs to be world-class in 10 minutes, and Europe's best organisers who need
to nod. Scored 1–5 on **Friction** (5 = zero effort to adopt), **Value** (5 = changes how
someone runs their event), **Durability** (5 = still useful in 2 years), **Nod factor**
(5 = a veteran screenshots it into the WhatsApp group).

| # | Format | Friction | Value | Durability | Nod | Verdict |
|---|--------|:---:|:---:|:---:|:---:|---------|
| 1 | Long-form guide (text) | 3 | 5 | 5 | 4 | **SHIP** — as a *field manual*, not an essay. It is the canonical knowledge base that every other format compiles from, including the agent. Layered: 10-min fast path up top, depth below. |
| 2 | Punchy slides | 4 | 2 | 2 | 3 | Skip. Slides decay, need design tooling, and say less per minute than a good cheat sheet. The agent pack can *generate* a deck on demand — better than us guessing one deck for everyone. |
| 3 | Short website frames | 3 | 3 | 2 | 3 | Skip. Jens/BuilderBase owns infra — "we don't need to recreate infra" was the brief. A website is a rendering of #1; build it later on top of the manual if the group wants it. |
| 4 | Gantt-style checklist w/ deadlines | 5 | 5 | 4 | 5 | **SHIP** — the single most screenshot-able artifact. Every one of the 35 sources converges on a countdown timeline; we can ship the consensus with hard numbers (200% overbooking, judge math, food decay curve). |
| 5 | Done-for-you agent pack | 4 | 5 | 4 | 5 | **SHIP** — the differentiator. Nobody in the playbook canon has this. Claude Code skill pack: clone, run `/scaffold`, answer 10 questions, get your entire event generated as files. The manual is its brain. |
| 6 | WhatsApp-native drip cards (1 cheat card/day) | 5 | 3 | 3 | 4 | Strong runner-up — perfect for *this* WhatsApp group as distribution. But it's a serialization of #1/#4, not new content. Derive it in 20 minutes once the manual exists. |
| 7 | Swipe file (copy-paste emails, prospectus, run-of-show) | 5 | 4 | 4 | 4 | **Folded into #5** — templates ship inside the agent pack's `templates/`, usable standalone without the agent. |
| 8 | Decision-tree format picker ("which hackathon should you run?") | 5 | 4 | 4 | 4 | **Folded into #1** — Chapter 1 of the manual is the picker. The single biggest research finding is that events fail through goal-incoherence, so the picker must be the front door, not a side artifact. |
| 9 | Interactive readiness scorecard | 4 | 2 | 2 | 3 | Skip. Fun, low substance, website-shaped (see #3). |
| 10 | Workshop-in-a-box (train-the-trainer kit) | 2 | 4 | 4 | 3 | Skip for v1. Highest leverage for the 1%→50% mission long-term (organisers training organisers), but heavy to build and needs the manual to exist first. Obvious v2. |

## The shipped trio and why it's coherent

```
FIELD MANUAL  ──is the brain of──▶  AGENT PACK
     │                                  │
     └──compiles to──▶  MASTER TIMELINE ◀──generates per-event──┘
```

One repo ships all three. The manual is the source of truth (and the veteran-nod
artifact). The timeline is the zero-friction cheat sheet (the WhatsApp-group artifact).
The agent pack is the "bachelor student to world-class in one prompt and 10 minutes"
promise made literal — it interviews you, then writes *your* timeline, budget, sponsor
prospectus, run-of-show, and comms calendar as files, citing the manual's numbers.

v2 backlog, in order: WhatsApp drip cards (#6), workshop-in-a-box (#10), website frames
on BuilderBase (#3).
