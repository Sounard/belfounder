# THE HACKATHON PLAYBOOK

**The onboarding that takes any bachelor student to world-class organiser in one
prompt and 10 minutes** — built for the community of Europe's hackathon organisers,
distilled from 35+ playbooks, retrospectives, and research papers.

The thesis: ~1% of people build things. Hackathons are the most reliable machine ever
invented for growing that number — the research shows their true output is *changed
people*, not code (~9% of "hackathon code" is even written at the event). This playbook
treats the builder-conversion as the product and shipped projects as a designable
add-on, and it works for campuses, companies, schools, civic programs, and family
weekends alike.

## The three artifacts

| Artifact | For | Time to value |
|---|---|---|
| **[Field Manual](playbook/FIELD-MANUAL.md)** | The doctrine. 10-minute fast path up top, eight chapters of depth (psychology, money, judging, the afterlife) below. The veteran-nod document. | 10 min |
| **[Master Timeline](checklist/MASTER-TIMELINE.md)** | Gantt-style countdown with every hard number and deadline. Two tracks: flagship weekend + 3–12h AI-era event. The screenshot-into-the-group-chat document. | 2 min |
| **[Agent Pack](agent-pack/README.md)** | Claude Code skill pack. `cd agent-pack && claude`, then `/scaffold` — a 10-question interview generates your entire event as files: timeline, budget, sponsor prospectus, run of show, judging plan, comms sequence. | 10 min |

Supporting: **[Format Debate](FORMAT-DEBATE.md)** (10 content formats scored, why these
3 shipped) · **[Insight Bank](research/INSIGHT-BANK.md)** (every load-bearing number and
principle, with sources).

## The five numbers to remember if you remember nothing

1. Free events no-show at **~50%** → register 200% of capacity.
2. Judges = **⌈(projects × 3 × 4 min) / window⌉**, and projects ≈ attendees ÷ 4.
3. Teams finish **~25%** of what they scope → checkpoint at half-time, demos 2–3 min.
4. Winning predicts **2 weeks** of follow-through; a written next-30-days plan and
   skill-fit teams predict months.
5. Only **~7%** of projects survive 6 months by default; designed follow-through hits
   25–40%. The afterlife is the event.

## v2 backlog

WhatsApp drip cards (1 cheat card/day for the organiser group) → workshop-in-a-box
(train-the-trainer) → web frames on BuilderBase infra.
