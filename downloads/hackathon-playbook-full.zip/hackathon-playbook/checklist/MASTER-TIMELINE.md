# THE MASTER TIMELINE

The consensus countdown of 35+ playbooks, with the hard numbers attached. Two tracks:
**Track A** — flagship weekend event (100–500 people, 24–48h). **Track B** — AI-era
compression event (50–150 people, 3–12h) in 6 weeks. Cross out what doesn't apply;
never add a phase without an owner.

Legend: `□` do it · **bold** = the deadline that hurts if missed · (§) = chapter in
`../playbook/FIELD-MANUAL.md`

---

## TRACK A — THE FLAGSHIP (T-minus 5 months)

```
T-5mo   T-4mo   T-3mo   T-2mo   T-1mo   T-2wk   T-1wk   T-0     T+1wk
├───────┼───────┼───────┼───────┼───────┼───────┼───────┼───────┤
GOAL &  BUDGET &        MARKETING       RUN OF  FINAL   GAME    CLOSE
TEAM    SPONSORS REGISTRATION  JUDGES   SHOW    PUSH    DAY     LOOP
VENUE ══════════╡                MENTORS  VENUE LOGISTICS
        SPONSOR PIPELINE ════════════════════╡
                REGISTRATION FUNNEL ══════════════════╡
```

### T-5 months — Decide (§1)
- □ **Pick ONE goal** (conversion / prototypes / community / recruiting / launch). Write
  it in one sentence. Every later decision inherits from it.
- □ Leadership team: lead + owners for logistics, finance, marketing, hacker experience.
  One accountable human per area.
- □ Date: check exam calendars, holidays, rival events.
- □ **Venue hunt starts NOW** — it can eat 40% of total effort. Warm intros first,
  ~3 pitches/week (never bulk), libraries and universities count.
- □ If student event: apply to MLH / lab support programs (OpenAI wants ≥1 month notice;
  most want 3–4).

### T-4 months — Fund (§4)
- □ Budget sheet: food $8–10/person/meal, snacks $10/person, shirts $5–8,
  **+$1–3k contingency, non-negotiable**.
- □ Prospectus: 2–3 pages, 3 tiers, each tier anchored to ONE sponsor lane
  (adoption / recruiting / brand), **top tier ≤25% of total budget**, prize parity rule.
- □ **Sponsor outreach opens**: plain-text first email, ZERO links/attachments, to
  DevRel/HR/Marketing titles or the CEO. Call → same-day proposal → 3 follow-ups,
  1–2 weeks apart → invoice on yes. (Q1/Q4 = loosest budgets.)
- □ Placeholder site + social handles live.

### T-3 months — Open (§5)
- □ Full website + **registration opens**. Application form primes builder identity
  (ask what they've made). If curating: publish the judge lineup before applications
  close.
- □ Marketing live: local community first, then expand. Milestones for a 500-person
  target: **100 signups by T-2mo, 250 by T-1mo, 600 by T-2wk, 1,000 by T-1wk**
  (free events no-show ~50%).

### T-2 months — Staff (§6)
- □ Judging plan: expect **1 project per 4 attendees**; judges =
  ⌈(projects × 3 × 4min) / window⌉. 175 projects / 2h → 18 judges. Book them.
- □ Rubric written (working demo · execution · originality · impact — consider
  *shippability*). It will be published at kickoff, decide it now.
- □ Mentors: slotted signup form; plan scheduled circulation, a #mentorship channel,
  a physical mentor station, a 1-page mentor guide.
- □ Workshops + mini-events scheduled at fixed windows (1 helper per 10–20; 45–90 min).
- □ Food vendors booked (order down the decay curve: 90% day-1 lunch → 30% day-2
  breakfast). Never pizza-only.
- □ Event software chosen (submissions, help queue, check-in). **Do not hand-roll
  day-of infra you haven't load-tested** — Hack Club's custom judging tool died at 15M
  requests mid-event.

### T-1 month — Choreograph (§5)
- □ Run of show, minute by minute, with an owner per block.
- □ Venue logistics closed: insurance, waivers, security list, AV, quiet room
  (**allow a full month from venue "yes"**).
- □ Transportation, dietary needs, accessibility.
- □ Comms cadence running: confirmation → logistics → hype. Redundant channels
  (email + chat + SMS).
- □ Team formation opens in Discord/matching form — **teams of 3–4 exist by hour zero,
  cap 5**.

### T-2 weeks — Converge
- □ Registration at 100% of physical capacity (keep pushing to 200%).
- □ **ONE consolidated paperwork deadline** for everything attendees owe (waivers,
  forms, teams). One date. Redundant reminders.
- □ Press/media outreach.

### T-1 week — Rehearse
- □ **Registration at 200% of capacity.**
- □ Judge + mentor final confirmations; 15-min judge calibration scheduled.
- □ Full-team run-of-show walkthrough + contingency plan (who decides what when X
  breaks).
- □ Final attendee email: what to bring, when to arrive, the one goal.
- □ Print handouts, signage, welcome slides. Venue walk-through at T-1 day.

### T-0 — Game day (§5, §6)
- □ Threshold moment at the door: named check-in, badge, music. QR + paper backup.
- □ Opening ≤15 min: mission cold-open → the ONE goal ("working demo, live, 18:00")
  → rubric published → rules in 5 min → go. Never open with wifi passwords.
- □ Protect build blocks; mentors circulate on schedule; **mid-point checkpoint**
  (teams finish ~25% of scope — force brutal scoping early).
- □ Meals at shared tables; one surprise micro-event; quiet room open; T-1h warning
  before hands-off.
- □ **Before demos: every team writes a 2-line next-30-days plan.**
- □ Demos: everyone, live, 2–3 min, hard cut, no slides. <200 people → full room;
  >200 → science fair, 3 judges/project, staggered, broadcast judging progress.
- □ Stack-rank scoring (top 3 per judge, 3/2/1); organizers validate + cheating-check
  the top 5.
- □ Double close: inward (winner stories, reflection) → outward (**announce the next
  date and the community channel from the stage**). Never end on prize logistics.

### T+1 week — Close the loop (§7)
- □ Surveys: attendees + sponsors, within 48h.
- □ **Sponsor report within 48h**: metrics, highlights, gallery links, re-up offer.
  This email is next year's budget.
- □ Pay every invoice; publish finances if you're brave (it's a fundraising asset).
- □ Public recap + winner-story posts (hand winners the megaphone).
- □ Projects live somewhere permanent (gallery, pinned repos).
- □ Follow-up container activated: demo day / hack night / incubation for top teams
  (the highest-impact budget line).
- □ Team retrospective, written, filed for the next organizer.

---

## TRACK B — THE COMPRESSION EVENT (T-minus 6 weeks, 3–12 hours)

The same skeleton, folded. What changes: no overnight logistics, curation replaces
volume, credits replace catering-scale budgets, and the demo is the entire product.

| When | Do |
|---|---|
| **T-6wk** | Goal + format (3h lightning / 12h build day). Venue via warm intro — one room, prestige-coded beats big. Sponsor = 1–2 partners providing credits + judges, not cash tiers. |
| **T-5wk** | Applications open (not registration). Form primes identity: GitHub, something shipped. **Publish the judge lineup now** — people apply to be seen by specific humans. Visible waitlist. |
| **T-4wk** | Confirm judges/mentors. Rubric written. Partner setup guide drafted (API keys, quickstarts) — **setup failure is the #1 killer of short formats**. |
| **T-3wk** | First acceptance wave. Publicize the funnel ("800 applied, 120 building"). Discord opens; team formation starts — **teams exist before hour zero or the event fails**. |
| **T-2wk** | Pre-event setup webinar / quickstart drop: every builder has working keys and a hello-world BEFORE the day. Final acceptances + waitlist promotions. |
| **T-1wk** | Run of show (for 12h: doors → 15-min opening → build → lunch → checkpoint → build → hard stop → demos → double close). Food: 1–2 meals + coffee, shared tables. Reminder cadence with countdown. |
| **T-0** | Threshold at the door. Mission cold-open. One goal on the wall with the clock. Mentors on a workflow (@mentor + rounds). Mid-point checkpoint. **Everyone demos, live, 2 min, no slides.** Access-prizes (dinner with the founders, early access, credits). Double close with the next date. |
| **T+72h** | Winner-story posts, gallery live, partner usage report, waitlist rolled into the next event's audience. |

---

## THE FIVE DEADLINES THAT KILL EVENTS

1. **Venue not signed by T-3 months** (Track A) — everything downstream blocks on it.
2. **Sponsor outreach starting after T-3 months** — pipelines take 6–10 weeks to close.
3. **Registration below 150% at T-1 week** — you will demo to an empty room.
4. **Teams not formed by hour zero** — the first 3 hours evaporate.
5. **No follow-up container announced at close** — the event evaporates instead.
