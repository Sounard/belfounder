# Insight Bank — distilled from 35+ playbooks, guides, and papers

Five parallel research sweeps: (1) canonical student/community playbooks, (2) tech
company / DevRel guides, (3) corporate & internal innovation programs, (4) civic
toolkits + academic research, (5) AI-era events + motivation science. Sources listed at
the bottom. These are the load-bearing facts the Field Manual, Master Timeline, and
Agent Pack are built on.

## The numbers that survive contact with reality

| Number | Fact | Source |
|---|---|---|
| 50% | No-show rate at free events. Register 200% of capacity by T-1 week. | MLH, hackathon.guide (65% show) |
| 1:4 | Submitted projects per checked-in attendee. | MLH 2026 season data |
| J = ⌈(P×3×4min)/T⌉ | Judge count: 3 judges/project, 4 min/visit. 175 projects in 2h → 18 judges. | MLH |
| 3/2/1 | Stack-rank scoring (each judge returns top 3 only) beats raw score sheets — normalizes harsh vs. generous judges. | MLH |
| $8–10 | Food per person per meal; snacks $10/person; +$1–3k contingency buffer, always. | MLH |
| 90→80→70→30→60% | Meal claim rates: day-1 lunch → dinner → midnight → day-2 breakfast → day-2 lunch. Order down the curve. | HackUTD/MLH |
| ~25% | Fraction of scoped work teams actually finish. Pitches 60s, demos 2–3 min, hard cap. | hackathon.guide |
| 40% | Share of total organizing effort the venue can eat. Pitch ~3 venues/week via warm intros; 1 month from "yes" to logistics done. | Hack Club Assemble |
| ≤25% | Max share of budget any single sponsor should cover. 3 tiers, 2–3 page prospectus. | MLH |
| 0 | Links/attachments/images allowed in a first sponsor email (spam filters). Follow up 3×, 1–2 weeks apart. Invoice the moment they say yes. | MLH |
| Q1/Q4 | Easiest quarters to extract sponsor money (budget cycles). Target DevRel, HR/recruiting, Marketing titles — or the CEO. Never a random engineer. | MLH |
| $500 vs $50k | If one sponsor prize dwarfs the others, every other sponsor's ROI dies. Enforce prize parity. | Devpost |
| ≥4 | Minimum prize count — participants estimate odds from prize-to-participant ratio. | Devpost |
| ~9% | Share of "hackathon code" actually written at the event (85% walks in the door). The event manufactures commitment, not code. | Imam et al., EMSE 2022, 22k projects |
| ~7% | Projects with any activity 6 months later, across 11,889 events. | Nolte et al., CSCW 2020 |
| 2 weeks vs months | Winning predicts short-term continuation only. Long-term: skill fit, skill diversity, small familiar teams, *written intention to continue*. | Nolte et al., CSCW 2020 |
| 25–40% | Shipped-or-roadmap rate at well-designed corporate programs (Grafana) vs the ~7% baseline. Design, not luck. | Grafana / Ainna funnel |
| 25–50% | Time-to-market reduction from a well-designed hackathon — the exec-pitch number. 80%+ of Fortune 100 run them. | McKinsey, AngelHack |
| 3.8% | Cerebral Valley acceptance rate (13,000 → 500). The rejection rate is the brand. | Cerebral Valley, Opus 4.6 event |
| 3h / 12h | ElevenLabs' 33-city 3-hour format; Anthropic's 12-hour Build Day. AI tooling killed the mandatory all-nighter. | ElevenLabs, Anthropic 2025 |
| −45% | Creativity drop under intense time pressure *without* mission framing (Amabile). Deadline needs meaning, and protected build blocks. | Amabile / flow research |
| 80–85% | How much of a facilitation slot to plan content for. Slack time is a design requirement. | MozFest |
| 5 | Max team size (cap it); 3–4 outperforms solos in finals. | NASA Space Apps, lablab.ai |
| 12–18 months | Full ROI cycle for an internal hackathon (registration → commercialized MVP). Say so before the event or be judged on week one. | Ainna / Devpost |

## The 12 principles (each source category converges on these)

1. **Goal first, everything inherits.** Events fail through goal-incoherence, not bad
   logistics. Community-building and prototype-production events should look almost
   nothing alike — teaming, judging, prizes all flip. (CMU Planning Kit's 12 decisions)
2. **Hackathons always produce subjects, only sometimes technology.** (Irani, 2015)
   The reliable output is a changed person. Design the identity transformation on
   purpose: witnessed demo = public enactment of "I am a builder" = how identity sticks.
3. **The real work is before and after; the middle should be sacred and almost
   rule-free.** Problem definition weeks ahead (RHoK), shipment orders posted before the
   event (Atlassian), demos to power 1–2 weeks *after* (Facebook's Prototype Forum),
   pre-committed follow-through budget (AngelHack: "the highest-impact budget line").
4. **Welcoming newcomers is an ops problem, not a vibe.** Imposter syndrome is the #1
   organizer job (Tauberer). Assign a human whose only role is walking first-timers to a
   first contribution. Parallel beginner workshops give "I don't know enough" a
   dignified landing place. Facebook's rule: first-timers must hack, no spectating.
5. **Theme, materials, and logistics are demographic instruments.** "Wear & Care"
   tripled women's participation with zero quotas (StitchFest). Childcare, humane hours,
   quiet rooms, non-coder prize categories (NASA's storytelling awards) change who comes
   and who feels expert.
6. **There is a hard tradeoff: familiar teams ship, stranger teams transform.**
   (Trainer et al., CSCW 2016). Pick per event goal; you can't max both.
7. **Curation is a product; scarcity is a mechanic.** Application-gated admission with a
   publicized funnel (13k→500) manufactures status. Parker's "generous exclusion": by
   closing the door you create the room. Open-entry works too — if the *submission* gate
   is brutal (lablab: working URL + video + repo, or you're not judged).
8. **Demo or die, time-boxed.** No slides. Working artifact, live, 2–3 minutes. Under
   ~200 people everyone demos to everyone; above, science fair + top-N on stage. The
   live demo's public risk is the bonding ritual and the honesty mechanism.
9. **Prizes are trophies, not contracts.** Expected performance-contingent rewards
   crowd out intrinsic motivation (Deci/Koestner/Ryan meta-analysis). Access > cash:
   dinner with founders, pitch time with execs, early model access, credits. Winning
   buys two weeks of commits; fit and purpose buy months.
10. **Engineer flow's three preconditions:** one clear goal ("working demo at 18:00"),
    immediate feedback (mentors on a workflow — @mentor channel + roaming schedule, not
    hallway luck), challenge/skill matching (tracks + starter templates). Sleep
    deprivation is anti-flow; the marathon was load-bearing when scaffolding took 20
    hours — it no longer does.
11. **Open with meaning, close in two phases.** (Priya Parker) The event starts at the
    invitation; create a threshold moment; never open with logistics. Close inward
    (stories, reflection) then outward (next date, community channel, where projects
    live). Never end on prize logistics.
12. **The event must live inside a container.** Recurring hack nights beat annual
    events for project survival (Code for America). Permanent public artifact pages,
    winner-story blogs, rolling waitlists — each event is an episode in a series. A
    hackathon that ends at the closing ceremony was designed for theater.

## The two warnings

- **Community energy is nearly unmonetizable as a standalone business.** Buildspace
  raised ~$97M, peaked at 10k+ builders, died three weeks after its most-loved event.
  Run hackathons as a channel for something else (ecosystem, talent, mission), not as
  the business.
- **The co-optation critique is real** (Zukin: "Work is Play, Exhaustion is Effervescent,
  Precarity is Opportunity"). Keep the ritual's emotional energy, but make the
  participant the primary beneficiary: their IP, their portfolio pages, their story.

## Source register (35+)

**Student/community canon:** hackathon.guide (Tauberer) · MLH Organizer Guide ·
Hack Club Assemble (open-sourced $75k event) · Hack Club hackathons directory ·
Devpost guides + judging criteria · HackMIT virtual retrospective (Jack Cook) ·
awesome-hackathon index · Stripe Community Builders Foundations (the Google Doc).

**Tech company / DevRel:** github/hackathons · Microsoft Garage Hackathon Playbook
(71k participants) · Devpost sponsor best practices · HackerEarth complete guide
(800+ events) · AngelHack organize/sponsor guides · twilio/hackathons + InfoQ ·
Lob Hackathon Playbook pts 1–2 · Susan Ibach on sponsorship ·
OpenAI community hackathon support · Anthropic Claude Code hackathon + Claude Campus.

**Corporate/internal:** Atlassian ShipIt (quarterly since 2005; shipment orders,
shippability criterion) · Spotify Hack Week + Fix It Week pivot · Shopify Hack Days ·
Facebook hackathon culture (Keyani; Prototype Forum; Like button) · McKinsey
"Demystifying the hackathon" · Bain/HBR "Hackathons aren't just for coders" ·
GV Design Sprint (Knapp) · Brightidea/IdeaScale/Devpost enterprise kits ·
Ainna nine-metric ROI funnel.

**Civic + academic:** NASA Space Apps organizer toolkit (93k participants, 163
countries) · Code for America Brigade Playbook · Random Hacks of Kindness / World Bank ·
MozFest Facilitator Guide + Open Canvas · CMU Hackathon Planning Kit (12 decisions) ·
Trainer et al. CSCW 2016 · Nolte et al. CSCW 2018/2020 · Imam et al. EMSE 2022 ·
Warner & Guo ICER 2017 · Nandi & Mandernach SIGSCE 2016 · "Make the Breast Pump Not
Suck" (feminist hackathon) · StitchFest SIGCSE 2015 · Irani 2015 · Zukin &
Papadantonakis 2017.

**AI-era + experience design:** Cerebral Valley · lablab.ai (100+ events/yr) ·
{Tech: Europe} city-tour model · Anthropic Build Day (12h) · Hugging Face Agents-MCP
hackathon · ElevenLabs 33-city 3-hour worldwide hackathon · AGI House merit-gate ·
Buildspace post-mortem · "Demo or Die" (Recht) · Octalysis (Chou) · Csikszentmihalyi
flow · Deci/Koestner/Ryan 1999 · Priya Parker, *The Art of Gathering* · TAIKAI "Death
of Hackathon Mode".

*(Access note: community-hackathon-playbook.lovable.app never responded from this
environment — worth a manual check; the shared Google Doc resolved to Stripe's
Community Builders curriculum and is digested above.)*
